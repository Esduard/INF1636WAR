package model;

enum Shape {
	Square,
	Triangle,
	Circle,
	Joker;
	
	
}


