import controller.GameController;
import model.TEST;

class Program {
	
	public static void main(String[] args) 
	{
//			System.out.println("-------------TEST MODEL INTIALIZE---------------");
//			TEST.testCreatePlayerList();
//			TEST.testAddPlayers();
//			TEST.testValidateCardTrade();
//			TEST.testValidateAttack();
//			TEST.testAttackResult();
//			TEST.testMoveTroops();
//			TEST.testObjectiveValidation();
//		
//			TEST.testCardTrade();

			GameController.getGameController();
		}
	
}
