package controller;

enum TurnState {
	armyPlacement,
	attack,
	armyMovement,
	cardDraw,
	ended
}
