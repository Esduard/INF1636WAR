package controller;

enum GameState {
	newGameMenu,
	chooseNumberOfPlayersMenu,
	playerRegisterMenu,
	game,
	ended
}
